10.json
quete objet.json:
  - a un texte d'achevement (message au joureur quand quete fini)
  - a un texte de quete (message dans le livre des quete)
  - type: Quete objet
  - pas répetable 
  - ce termine en parlant a un pnj
  - ne déclange pas un mail une fois fini
  - ne déclange pas une quete une fois fini

9.json
tue 50 cochon.json:
  - a un texte d'achevement (message au joureur quand quete fini)
  - a un texte de quete (message dans le livre des quete)
  - type: Quete kill
  - répetable 
  - ce termine en parlant a un pnj
  - ne déclange pas un mail une fois fini
  - ne déclange pas une quete une fois fini

2.json
"va choisir une arme.json"
  - a un texte d'achevement (message au joureur quand quete fini)
  - a un texte de quete (message dans le livre des quete)
  - type: Quete d'Objet (mais on demande d'objet et la quete deviens juste parler a un pnj)
  - pas répetable 
  - ce termine en parlant a un pnj
  - ne déclange pas un mail une fois fini
  - ne déclange pas une quete une fois fini

5.json
"va voir le maquain d'entraienemnt.json"
  - a un texte d'achevement (message au joureur quand quete fini)
  - a un texte de quete (message dans le livre des quete)
  - type: Quete location
  - pas répetable 
  - ce termine en parlant a un pnj
  - déclange un mail une fois fini
  - déclange une quete une fois fini

1.json:
"Parle_au_forgerons.json"
  - a un texte d'achevement (message au joureur quand quete fini)
  - a un texte de quete (message dans le livre des quete)
  - type: Quete d'Objet (mais on demande d'objet et la quete deviens juste parler a un pnj)
  - récompance: exp + items aléatoire
  - pas répetable 
  - ce termine en parlant a un pnj
  - ne déclange pas d'envoie de mail
  - ne déclange pas de quete une fois fini
