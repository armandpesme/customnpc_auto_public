clones:
  Bob.json:
    dialogue: 1_bob_intro.json
    marquage:
      - disponible: point d'exclamation
      - en_cours: point d'interrogation
 
 tu n'as que c'est parti la a gerer le reste tu copie colle le json long.
