package noppes.npcs.api.entity;

import net.minecraft.world.entity.animal.Animal;

public interface IAnimal<T extends Animal> extends IMob<T> {
	
}
