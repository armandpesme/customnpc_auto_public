package noppes.npcs.api.entity;

import net.minecraft.world.entity.projectile.AbstractArrow;

public interface IArrow<T extends AbstractArrow> extends IEntity<T>{
	
}
