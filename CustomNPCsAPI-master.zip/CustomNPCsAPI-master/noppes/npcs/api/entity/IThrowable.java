package noppes.npcs.api.entity;

import net.minecraft.world.entity.projectile.ThrowableProjectile;

public interface IThrowable<T extends ThrowableProjectile> extends IEntity<T>{

}
