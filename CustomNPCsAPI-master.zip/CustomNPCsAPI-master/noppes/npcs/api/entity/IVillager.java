package noppes.npcs.api.entity;

import net.minecraft.world.entity.Mob;

public interface IVillager<T extends Mob> extends IMob<T> {

	
}
