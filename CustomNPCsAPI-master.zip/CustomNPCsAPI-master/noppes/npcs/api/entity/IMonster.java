package noppes.npcs.api.entity;

import net.minecraft.world.entity.Mob;

public interface IMonster<T extends Mob> extends IMob<T> {

}
