package noppes.npcs.api.entity.data;

public interface INPCRole {
	
	public int getType();
	
}
