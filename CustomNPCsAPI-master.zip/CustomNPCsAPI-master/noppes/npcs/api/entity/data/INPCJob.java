package noppes.npcs.api.entity.data;

public interface INPCJob {

	public int getType();
	
}
