package noppes.npcs.api.entity.data.role;

public interface IJobBuilder {

	public boolean isBuilding();

}
