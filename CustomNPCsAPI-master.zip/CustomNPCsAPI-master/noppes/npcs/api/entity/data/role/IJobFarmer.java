package noppes.npcs.api.entity.data.role;

public interface IJobFarmer {

	public boolean isPlucking();

}
