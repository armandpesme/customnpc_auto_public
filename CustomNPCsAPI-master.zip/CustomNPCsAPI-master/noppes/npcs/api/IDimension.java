package noppes.npcs.api;

public interface IDimension {

	public String getId();
}
