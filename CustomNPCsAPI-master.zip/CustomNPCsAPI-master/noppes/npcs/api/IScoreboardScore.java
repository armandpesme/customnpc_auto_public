package noppes.npcs.api;

public interface IScoreboardScore {

	public int getValue();
	
	public void setValue(int val);
	
	public String getPlayerName();
}
