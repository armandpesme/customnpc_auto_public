package noppes.npcs.api.item;

import noppes.npcs.api.block.IBlock;

public interface IItemBlock extends IItemStack {

	public String getBlockName();
	
}
