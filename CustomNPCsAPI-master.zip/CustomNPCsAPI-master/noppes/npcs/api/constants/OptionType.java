package noppes.npcs.api.constants;

public class OptionType {
	public static final int QUIT_OPTION = 0;
	public static final int DIALOG_OPTION = 1;
	public static final int DISABLED = 2;
	public static final int ROLE_OPTION = 3;
}
