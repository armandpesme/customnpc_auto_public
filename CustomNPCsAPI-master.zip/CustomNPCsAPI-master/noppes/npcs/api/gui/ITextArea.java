package noppes.npcs.api.gui;

public interface ITextArea extends ITextField {

    ITextArea setCodeTheme(boolean bo);
    boolean getCodeTheme();

}
