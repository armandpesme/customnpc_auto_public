package noppes.npcs.api.gui;

public interface IComponentsScrollableWrapper extends IComponentsWrapper {

    IComponentsScrollableWrapper init(int x, int y, int width, int height);

}
